The website is not created under CCSE servers due to some problems. But it will be created later. However, the work is on Github under the following link:
https://github.com/MagedSaeed/CS_SWE_Degree_Plan/tree/master/HW

